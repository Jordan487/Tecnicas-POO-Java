package entidades;

public class Auto extends Vehiculo {
    @Override
    public void moverse() {
        System.out.println("El auto acelera sobre el asfalto.");
    }
}