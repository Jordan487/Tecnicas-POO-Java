package entidades;

public class Vehiculo {
    
    public void encender() {
        System.out.println("Vehiculo encendido.");
    }
    
    public void moverse() {
        System.out.println("Vehiculo en movimiento.");
    }
}