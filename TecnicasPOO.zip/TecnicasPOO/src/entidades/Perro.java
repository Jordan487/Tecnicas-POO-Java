package entidades;

public class Perro extends Animal {

    private String nombre;

    public Perro(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void hacerSonido() {
        System.out.println(nombre + " hace guau guau.");
    }
}